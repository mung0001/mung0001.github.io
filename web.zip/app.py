from flask import Flask, render_template, Blueprint,  request,  redirect, url_for
import requests
import urllib3
import ssl
from flask_mysqldb import MySQL
from datetime import datetime


app = Flask(__name__)
mysql = MySQL(app)

bp = Blueprint('app', __name__, static_folder='static', template_folder='templates')
app.register_blueprint(bp)

app.config['MYSQL_HOST'] = '172.21.49.5'
app.config['MYSQL_USER'] = 'test'
app.config['MYSQL_PASSWORD'] = 'qwer1234'
app.config['MYSQL_DB'] = 'test'



@app.route('/')
def home():
    
    # Fetch data from the storage table
    cur_notice_infra = mysql.connection.cursor()
    cur_notice_infra.execute("SELECT * FROM notice_infra")
    columns_notice_infra = [col[0] for col in cur_notice_infra.description]
    data_notice_infra = [dict(zip(columns_notice_infra, row)) for row in cur_notice_infra.fetchall()]
    cur_notice_infra.close()

    return render_template('home.html', data_notice_infra=data_notice_infra)

class HttpAdapterCustom(requests.adapters.HTTPAdapter):
    def __init__(self, ssl_context=None, **kwargs):
        self.ssl_context = ssl_context
        super().__init__(**kwargs)

    def init_poolmanager(self, connections, maxsize, block=False):
        self.poolmanager = urllib3.poolmanager.PoolManager(
            num_pools=connections, maxsize=maxsize, block=block,
            ssl_context=self.ssl_context)

# Railkit 라우팅
@app.route('/Railkit')
def Railkit():    
    # Fetch data from the railkit table
    cur_railkit = mysql.connection.cursor()
    cur_railkit.execute("SELECT * FROM railkit")
    columns_railkit = [col[0] for col in cur_railkit.description]
    data_railkit = [dict(zip(columns_railkit, row)) for row in cur_railkit.fetchall()]
    cur_railkit.close()    
    return render_template('Railkit.html',  data_railkit=data_railkit )


@app.route('/get_api_data', methods=['POST'])
def get_api_data():
    in_serials = request.form.get('serial_numbers')

    class HttpAdapterCustom(requests.adapters.HTTPAdapter):
        def __init__(self, ssl_context=None, **kwargs):
            self.ssl_context = ssl_context
            super().__init__(**kwargs)

        def init_poolmanager(self, connections, maxsize, block=False):
            self.poolmanager = urllib3.poolmanager.PoolManager(
                num_pools=connections, maxsize=maxsize, block=block,
                ssl_context=self.ssl_context)

    ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    ctx.options |= 0x04  # 0x04: OP_LEGACY_SERVER_CONNECT

    session = requests.session()
    session.mount('https://', HttpAdapterCustom(ctx))
    
    serial_numbers = in_serials.split()
    api_data_list = []
    for in_serial in serial_numbers:

        body = {
            "search_or": [{"key": "serial_number", "value": in_serial, "option": "eq"},
                       {"key": "server.host_name", "value": in_serial, "option": "eq"},                       ],
            "page": {"limit": 10},
            "output_values": [    
    "cid",
    "manufacturer_code",
    "model_name",
    "serial_number",
    "standard_type.standard_type",
    "unit_size",
    "cpu_model",
    "division_code",
    "owner_code",
    "ownership_code",
    "state_code",
    "datacenter.name_code",
    "rackmount.rack.name",
    "reservation_code",
    "deploy_target",
    "created_at",
    "created_user",
    "server.service_state_code",
    "server.host_name",
    "server.primary_ip",
    "server.platform_type_code",
    "server.project.full_path",
    "server.purpose_code",
    "server.cpu_core",
    "server.memory_size",
    "server.os_type_code",
    "server.os_distro",
    "server.os_name",
    "server.os_arch",
    "server.reboot_target_code",
    "server.id",
    "datacenter.name",
    "rackmount.rack.rackrow.rackroom.name",
    "rackmount.rack.rackrow.name",
    "server.priority",
    "server.project.name",
    "rackmount.start_position",
    "server.server_tag.tag_key",
    "server.server_tag.tag_value",
    "server.parent.platform_type_code",
    "server.children.host_name",
    "server.children.primary_ip",
    "server.nic.ip_address",
    "server.nic.mac_address",
    "server.nic.interface_name",
    "server.software.sw_name",
    "server.route.destination",
    "server.route.gateway",
    "server.process.proc_name",
    "server.kubernetes.cluster.pod.name",
    "cpu.model_name",
    "cpu.manufacturer_code",
    "cpu.clock",
    "cpu.core_num",
    "cpu.hyperthread",
    "disk.model_name",
    "memory.model_name",
    "nic.model_name",
    "nic.mac_address",
    "bmc.mac_address",
    "raid_controller.name"]
        }
        res = session.post("https://apis.ncsoft.net/cmdb/v2/server/server/filter", headers={"Authorization": "Bearer ebVnzyM6czBRbIIzeZ7HMj:QO3n3hcyCEwvx5k92JAUAij14DoJMjLPAf4lxbzUDQQc"}, json=body)

        if res.status_code == 200:
            if res.status_code == 200:
                api_data = res.json().get('results', [])
                api_data_list.append(api_data)
        else:
            api_data = None
            error_message = f"API request failed. Status code: {res.status_code}"
            print(error_message)

    return render_template('api.html', api_data_list=api_data_list)




@app.route('/part')
def part():
    # Fetch data from the storage table
    cur_storage = mysql.connection.cursor()
    cur_storage.execute("SELECT * FROM storage")
    columns_storage = [col[0] for col in cur_storage.description]
    data_storage = [dict(zip(columns_storage, row)) for row in cur_storage.fetchall()]
    cur_storage.close()

    # Fetch data from the memory table
    cur_memory = mysql.connection.cursor()
    cur_memory.execute("SELECT * FROM memory")
    columns_memory = [col[0] for col in cur_memory.description]
    data_memory = [dict(zip(columns_memory, row)) for row in cur_memory.fetchall()]
    cur_memory.close()

    # Fetch data from the networkcard table
    cur_networkcard = mysql.connection.cursor()
    cur_networkcard.execute("SELECT * FROM networkcard")
    columns_networkcard = [col[0] for col in cur_networkcard.description]
    data_networkcard = [dict(zip(columns_networkcard, row)) for row in cur_networkcard.fetchall()]
    cur_networkcard.close()

    return render_template('part.html', data_storage=data_storage, data_memory=data_memory, data_networkcard=data_networkcard)

# api test
@app.route('/api')
def api():
    return render_template('api.html' )


@app.route('/Test')
def Test():
    return render_template('Test.html' )

@app.route('/Ticket')
def Ticket():
    return render_template('Ticket.html')



@app.route('/Ticket_Create', methods=['GET', 'POST'])
def submit_ticket():
    if request.method == 'POST':
        ticket_type = request.form.get('Ticket_A')
        work_type = request.form.get('Work_A')
        jsb_number = request.form.get('JSB_A')
        target_equipment = request.form.get('Asset_A')
        worker = request.form.get('Worker_A')
        completion_status = request.form.get('Secess_A')
        additional_notes = request.form.get('ETC_A')

        current_date = datetime.now().strftime('%Y%m%d')
        connection = mysql.connection
        cursor = connection.cursor()

        cursor.execute('SELECT MAX(id) FROM ticket_data')
        last_id = cursor.fetchone()[0]

        if last_id is None:
            new_id = f'TAS{current_date}0001'
        else:
            last_id_number = int(last_id[12:])
            new_id_number = last_id_number + 1
            new_id = f'TAS{current_date}{str(new_id_number).zfill(4)}'

        cursor.execute('''
            INSERT INTO ticket_data
            (id, ticket_type, work_type, jsb_number, target_equipment, worker, completion_status, additional_notes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ''', (new_id, ticket_type, work_type, jsb_number, target_equipment, worker, completion_status, additional_notes))

        connection.commit()
        cursor.close()

        return redirect(url_for('submit_ticket'))

    return render_template('Ticket.html')



@app.route('/Task')
def Task():
    cur_task = mysql.connection.cursor()
    cur_task.execute("SELECT * FROM ticket_data")
    columns_task = [col[0] for col in cur_task.description]
    data_task = [dict(zip(columns_task, row)) for row in cur_task.fetchall()]
    cur_task.close()

    return render_template('Task.html', data_task=data_task)



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, threaded=True, debug=True)
