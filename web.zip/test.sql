-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Server`
--

DROP TABLE IF EXISTS `Server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Server` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `RackLocation` varchar(255) DEFAULT NULL,
  `Layer` int DEFAULT NULL,
  `PreviousType` varchar(50) DEFAULT NULL,
  `ChangeType` varchar(50) DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Availability` varchar(10) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `Service` varchar(50) DEFAULT NULL,
  `Purpose` varchar(50) DEFAULT NULL,
  `PreviousUsage` varchar(255) DEFAULT NULL,
  `LanIP` varchar(15) DEFAULT NULL,
  `BIOSVersion` varchar(50) DEFAULT NULL,
  `Manufacturer` varchar(50) DEFAULT NULL,
  `Model` varchar(50) DEFAULT NULL,
  `SerialNumber` varchar(50) DEFAULT NULL,
  `CPUSpecification` varchar(255) DEFAULT NULL,
  `CurrentDisk1` varchar(50) DEFAULT NULL,
  `CurrentDisk2` varchar(50) DEFAULT NULL,
  `RaidControllerModel` varchar(50) DEFAULT NULL,
  `CurrentMemory` varchar(50) DEFAULT NULL,
  `CurrentMemory2` varchar(50) DEFAULT NULL,
  `NIC1` varchar(50) DEFAULT NULL,
  `NIC2` varchar(50) DEFAULT NULL,
  `NIC3` varchar(50) DEFAULT NULL,
  `NIC4` varchar(50) DEFAULT NULL,
  `NIC5` varchar(50) DEFAULT NULL,
  `AdditionalNotes` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Server`
--

LOCK TABLES `Server` WRITE;
/*!40000 ALTER TABLE `Server` DISABLE KEYS */;
/*!40000 ALTER TABLE `Server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServerInventory`
--

DROP TABLE IF EXISTS `ServerInventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServerInventory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `RackLocation` varchar(255) DEFAULT NULL,
  `Layer` int DEFAULT NULL,
  `PreviousType` varchar(50) DEFAULT NULL,
  `ChangeType` varchar(50) DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Availability` varchar(10) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `Service` varchar(50) DEFAULT NULL,
  `Purpose` varchar(50) DEFAULT NULL,
  `PreviousUsage` varchar(255) DEFAULT NULL,
  `LanIP` varchar(15) DEFAULT NULL,
  `BIOSVersion` varchar(50) DEFAULT NULL,
  `Manufacturer` varchar(50) DEFAULT NULL,
  `Model` varchar(50) DEFAULT NULL,
  `SerialNumber` varchar(50) DEFAULT NULL,
  `CPUSpecification` varchar(255) DEFAULT NULL,
  `CurrentDisk1` varchar(50) DEFAULT NULL,
  `CurrentDisk2` varchar(50) DEFAULT NULL,
  `RaidControllerModel` varchar(50) DEFAULT NULL,
  `CurrentMemory` varchar(50) DEFAULT NULL,
  `CurrentMemory2` varchar(50) DEFAULT NULL,
  `NIC1` varchar(50) DEFAULT NULL,
  `NIC2` varchar(50) DEFAULT NULL,
  `NIC3` varchar(50) DEFAULT NULL,
  `NIC4` varchar(50) DEFAULT NULL,
  `NIC5` varchar(50) DEFAULT NULL,
  `AdditionalNotes` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServerInventory`
--

LOCK TABLES `ServerInventory` WRITE;
/*!40000 ALTER TABLE `ServerInventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServerInventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) NOT NULL,
  `row_id` int NOT NULL,
  `operation` varchar(10) NOT NULL,
  `operation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memory`
--

DROP TABLE IF EXISTS `memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `vendor` varchar(255) NOT NULL,
  `KR0` int NOT NULL,
  `KR1` int NOT NULL,
  `KR2` int NOT NULL,
  `total` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memory`
--

LOCK TABLES `memory` WRITE;
/*!40000 ALTER TABLE `memory` DISABLE KEYS */;
INSERT INTO `memory` VALUES (1,'DDR4-2400 8GB','Dell',0,0,0,0),(2,'DDR4-2400 8GB','HPE',54,0,0,54),(3,'DDR4-2400 16GB','Dell',18,0,0,18),(4,'DDR4-2400 16GB','HPE',1611,150,0,1761),(5,'DDR4-2400 32GB','Dell',12,0,0,12),(6,'DDR4-2400 32GB','HPE',865,16,0,881),(7,'DDR4-2666 8GB','Dell',0,0,0,0),(8,'DDR4-2666 8GB','HPE',117,0,0,117),(9,'DDR4-2666 16GB','Dell',20,4,10,34),(10,'DDR4-2666 16GB','HPE',209,0,12,221),(11,'DDR4-2666 32GB','Dell',1,0,0,1),(12,'DDR4-2666 32GB','HPE',12,56,12,80),(13,'DDR4-2933 8GB','Dell',72,0,36,108),(14,'DDR4-2933 8GB','HPE',555,360,218,1133),(15,'DDR4-2933 16GB','Dell',8,5,3,16),(16,'DDR4-2933 16GB','HPE',35,1,29,65),(17,'DDR4-2933 32GB','Dell',3,0,1,4),(18,'DDR4-2933 32GB','HPE',16,87,38,141),(19,'DDR4-3200 16GB','Dell',30,58,67,155),(20,'DDR4-3200 16GB','HPE',17,53,59,129),(21,'DDR4-3200 32GB','Dell',41,771,112,924),(22,'DDR4-3200 32GB','HPE',68,11,11,90);
/*!40000 ALTER TABLE `memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkcard`
--

DROP TABLE IF EXISTS `networkcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkcard` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `vendor` varchar(255) NOT NULL,
  `KR0` int NOT NULL,
  `KR1` int NOT NULL,
  `KR2` int NOT NULL,
  `total` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkcard`
--

LOCK TABLES `networkcard` WRITE;
/*!40000 ALTER TABLE `networkcard` DISABLE KEYS */;
INSERT INTO `networkcard` VALUES (1,'1G 4port 366FLR UTP','Dell',0,0,0,0),(2,'1G 4port 366FLR UTP','HPE',3,20,0,23),(3,'10G 2port 546FLR SFP+','Dell',0,0,0,0),(4,'10G 2port 546FLR SFP+','HPE',36,0,0,36),(5,'10G 2port 561FLR-T UTP','Dell',0,0,0,0),(6,'10G 2port 561FLR-T UTP','HPE',0,0,1,1),(7,'1G 4port I350-T4 UTP','Dell',3,15,7,25),(8,'1G 4port I350-T4 UTP','HPE',10,0,0,0),(9,'10G 2port 546 SFP+','Dell',0,0,0,0),(10,'10G 2port 546 SFP+','HPE',10,6,0,16),(11,'10G 2port 560 SFP+','Dell',0,0,0,0),(12,'10G 2port 560 SFP+','HPE',4,0,0,4),(13,'10G 2port 562 SFP+','Dell',0,0,0,0),(14,'10G 2port 562 SFP+','HPE',6,6,1,13),(15,'10G 2port 521T UTP','Dell',0,0,0,0),(16,'10G 2port 521T UTP','HPE',6,0,0,6),(17,'10G 2port 530T UTP','Dell',0,0,0,0),(18,'10G 2port 530T UTP','HPE',2,0,0,2),(19,'10G 2port 561T UTP','Dell',0,0,0,0),(20,'10G 2port 561T UTP','HPE',3,2,0,5),(21,'10G 2port 562T UTP','Dell',0,0,0,0),(22,'10G 2port 562T UTP','HPE',34,192,20,246),(23,'10G 2port X550 UTP','Dell',0,3,0,3),(24,'10G 2port X550 UTP','HPE',0,0,0,0),(25,'10G 2port Qlogic UTP','Dell',0,30,0,30),(26,'10G 2port Qlogic UTP','HPE',0,0,0,0),(27,'10G 2Port Broadcom','Dell',0,198,0,198),(28,'10G 2Port Broadcom','HPE',0,0,0,0);
/*!40000 ALTER TABLE `networkcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_infra`
--

DROP TABLE IF EXISTS `notice_infra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_infra` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_date` date NOT NULL,
  `content` text NOT NULL,
  `manager_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_infra`
--

LOCK TABLES `notice_infra` WRITE;
/*!40000 ALTER TABLE `notice_infra` DISABLE KEYS */;
INSERT INTO `notice_infra` VALUES (1,'2022-11-04','출입증 신청 시 출입층에 기계 라벨 이름으로 기입 필요 2F-02-1, 2 / 2F-10-1, 2 / 2F-61-1,2 / 2F-62-1, 2 / 5F-02-1, 2 / 5F-04-1, 2 / 5F-08-1, 2 / 5층 서버실','주효진'),(2,'2022-11-04','출입증 신청 시 출입층에 기계 라벨 이름으로 기입 필요 2F-02-1, 2 / 2F-10-1, 2 / 2F-61-1,2 / 2F-62-1, 2 / 5F-02-1, 2 / 5F-04-1, 2 / 5F-08-1, 2 / 5층 서버실','주효진'),(3,'2022-11-04','IP 설정 시 172.20.0.0/14 대역 ROUTE TABLE 업데이트 필요','위욱량'),(4,'2023-11-22','H750 레이드 컨트롤러 장착된 서버는 라이브 투입 X, 장애 교체용으로만 사용!','최준희'),(5,'2022-11-07','KR2 가산IDC 관제실 10LAN망 ACL 신청 협조 요청 > 10.181.0.0/26 대역으로 신청 완료 (위욱량님) > 사용하는 ip로 신청해야되서 차주 월요일에 ip 재전달 예정 NW : 10.181.0.0/26 GW : 10.181.0.62 10LanPC IP : 10.181.0.1~30번까지 사용 가능 (추가 사용 필요시 채정호님께 전달)','채정호'),(6,'2022-11-09','가산센터 상황실 : 서버실 작업 물품, 온도, 습도 관련 서버실 관련 전체 문의 (02-6266-6160, idc5@skbroadband.com)','주효진');
/*!40000 ALTER TABLE `notice_infra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `railkit`
--

DROP TABLE IF EXISTS `railkit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `railkit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vender` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `unit_size` varchar(255) NOT NULL,
  `KR0` int NOT NULL,
  `KR1` int NOT NULL,
  `KR2` int NOT NULL,
  `total` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `railkit`
--

LOCK TABLES `railkit` WRITE;
/*!40000 ALTER TABLE `railkit` DISABLE KEYS */;
INSERT INTO `railkit` VALUES (1,'HP','g80(inner)','1U',111,112,134,111),(2,'HP','g80(outter)','1U',111,112,134,111),(3,'DELL','630(inner)','1U',111,1112,1134,111);
/*!40000 ALTER TABLE `railkit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage`
--

DROP TABLE IF EXISTS `storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `vendor` varchar(255) NOT NULL,
  `KR0` int NOT NULL,
  `KR1` int NOT NULL,
  `KR2` int NOT NULL,
  `total` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage`
--

LOCK TABLES `storage` WRITE;
/*!40000 ALTER TABLE `storage` DISABLE KEYS */;
INSERT INTO `storage` VALUES (1,'SSD 480GB 2.5\"','Dell',4,0,10,14),(2,'SSD 480GB 2.5\"','HPE',1414,70,164,1648),(3,'SSD 800GB 2.5\"','Dell',0,0,0,0),(4,'SSD 800GB 2.5\"','HPE',400,6,0,406),(5,'SSD 960GB 2.5\"','Dell',70,63,131,264),(6,'SSD 960GB 2.5\"','HPE',726,438,412,1576),(7,'SSD 3.84TB 2.5\"','Dell',21,24,13,58),(8,'SSD 3.84TB 2.5\"','HPE',40,262,7,309),(9,'SAS 2.4TB 2.5\"','Dell',71,104,46,221),(10,'SAS 2.4TB 2.5\"','HPE',228,21,29,278),(11,'SAS 6TB 3.5\"','Dell',0,0,0,0),(12,'SAS 6TB 3.5\"','HPE',187,44,10,241),(13,'SAS 8TB 3.5\"','Dell',0,2,0,2),(14,'SAS 8TB 3.5\"','HPE',36,15,0,51),(15,'SAS 12TB 3.5\"','Dell',0,20,0,20),(16,'SAS 12TB 3.5\"','HPE',46,12,0,58);
/*!40000 ALTER TABLE `storage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-29 17:31:05
